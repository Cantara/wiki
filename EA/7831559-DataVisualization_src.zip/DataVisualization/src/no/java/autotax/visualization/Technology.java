package no.java.autotax.visualization;

import prefuse.util.ui.UILib;

import javax.swing.*;

/**
 * @author <a href=mailto:bard.lind@objectware.no>Bard Lind</a>
 */
public class Technology {
    public static void main(String argv[]) {
        UILib.setPlatformLookAndFeel();


       String filename = "/Users/bard/Projects/Prosjekter/Auto-taxonomy/DataVisualization/src/data/auto-taxonomy-technology.xml";
        String label = "name";
        if ( argv.length > 1 ) {
            filename = argv[0];
            label = argv[1];
        }
        JComponent treemap = TreeMap.demo(filename, label);

        JFrame frame = new JFrame("Technology");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(treemap);
        frame.pack();
        frame.setVisible(true);
    }

}
