
google.load("language", "1");

var originalText; 


function translate() {
	var text = document.getElementById('content').value;
	originalText = text ; 
	google.language.detect(text, function(result) {
	if (!result.error && result.language) {
		google.language.translate(text, result.language, "en",function(result) {
			var translated = document.getElementById('content');
			if (result.translation) {translated.value = result.translation;}
			// if (result.translation) {translated.innerHTML = result.translation;}
		});
		}
	});
}


function undoTranslate(){
	var translated = document.getElementById("text2");		
	translated.innerHTML = originalText;	
}





function submitPost() {
	sessionStorage.setItem('tempTitle', document.getElementById("title").value);
	sessionStorage.setItem('tempAuthor', document.getElementById("author").value);
	sessionStorage.setItem('tempDate', document.getElementById("date").value);
	sessionStorage.setItem('tempContent', document.getElementById("content").innerHTML);

	
	addNewPost();

}







function addNewPost() {
 	  

	var ni = document.getElementById('articleSection');
	var numi = document.getElementById('theValue');
	var num = (document.getElementById('theValue').value -1)+ 2;
	numi.value = num;
  	var newArticle = document.createElement('article');
  	var divIdName = 'my'+num+'Div';
  	newArticle.setAttribute('id',divIdName);
  	ni.appendChild(newArticle);
	
	
	//var article = document.getElementById('articleSection');


	var newTitle = document.createElement('text');
	var divIdName = 'my'+num+'Title';
	newTitle.setAttribute('id',divIdName);
	newTitle.innerHTML = sessionStorage.getItem('tempTitle');
	newArticle.appendChild(newTitle);

	var newAuthorName = document.createElement('text');
	var divIdName = 'my'+num+'AutorName';
	newAuthorName.setAttribute('id',divIdName);
	newAuthorName.innerHTML = sessionStorage.getItem('tempAuthor');
	newArticle.appendChild(newAuthorName);
	
	
	var newPubDate = document.createElement('text');
	var divIdName = 'my'+num+'newPubDate';
	newPubDate.setAttribute('id',divIdName);
	newPubDate.innerHTML = getDateStringDisplay();
	newArticle.appendChild(newPubDate);
	

	var newdiv = document.createElement('text');
	var divIdName = 'my'+num+'Content';
	newdiv.setAttribute('id',divIdName);
	sessionStorage.getItem('tempContent');
	newdiv.innerHTML =sessionStorage.getItem('tempContent');
	newArticle.appendChild(newdiv);

	
	
	sessionStorage.removeItem('tempTitle');
	sessionStorage.removeItem('tempAuthor');
	sessionStorage.removeItem('tempDate');
	sessionStorage.removeItem('tempContent');
	
	
	document.getElementById("title").value="";
	document.getElementById("author").value ="";
	document.getElementById("date").value="";
	document.getElementById("content").innerHTML="";

	
  	
}




function removeElement(divNum) {
  var d = document.getElementById('myDiv');
  var olddiv = document.getElementById(divNum);
  d.removeChild(olddiv);
}

function getDateStringDisplay(){
	var currentTime = new Date();
	var month = currentTime.getMonth() + 1;
	var day = currentTime.getDate();
	var year = currentTime.getFullYear();
	var hour = currentTime.getHours();
	var minutes = currentTime.getMinutes();
 	var postingDate =month + "/" + day + "/" + year + "  " + hour + ":" +minutes; 
	return postingDate;
}

