/*
 * Licensed to "Neo Technology," Network Engine for Objects in Lund AB
 * (http://neotechnology.com) under one or more contributor license agreements.
 * See the NOTICE file distributed with this work for additional information
 * regarding copyright ownership. Neo Technology licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of the License
 * at (http://www.apache.org/licenses/LICENSE-2.0). Unless required by
 * applicable law or agreed to in writing, software distributed under the
 * License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
 * OF ANY KIND, either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */

import org.neo4j.api.core.*;
import org.neo4j.api.core.Traverser.Order;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MatrixTest {
    public enum MyRelationshipTypes implements RelationshipType {
        KNOWS, CODED_BY, ROOT
    }

    private static Node neoNode;
    NeoService neo = new EmbeddedNeo("var/base");


    @BeforeClass
    public void createMatrix() {
        Transaction tx = Transaction.begin();
        try {
            Node referenceNode = neo.getReferenceNode();
            referenceNode.setProperty("NAME", "referenceNode");
            referenceNode.setProperty("NODE_TYPE", "referenceNode");
            Node thomas = neo.createNode();
            thomas.setProperty("name", "Thomas Andersson");
            thomas.setProperty("age", 29);
            neoNode = thomas;
            referenceNode.createRelationshipTo(neoNode, MyRelationshipTypes.ROOT);
            Node trinity = neo.createNode();
            trinity.setProperty("name", "Trinity");
            Relationship rel = thomas.createRelationshipTo(trinity, MyRelationshipTypes.KNOWS);
            rel.setProperty("age", "3 days");
            Node morpheus = neo.createNode();
            morpheus.setProperty("name", "Morpheus");
            morpheus.setProperty("rank", "Captain");
            morpheus.setProperty("occupation", "Total badass");
            thomas.createRelationshipTo(morpheus, MyRelationshipTypes.KNOWS);
            rel = morpheus.createRelationshipTo(trinity, MyRelationshipTypes.KNOWS);
            rel.setProperty("age", "12 years");
            Node cypher = neo.createNode();
            cypher.setProperty("name", "Cypher");
            cypher.setProperty("last name", "Reagan");
            rel = morpheus.createRelationshipTo(cypher, MyRelationshipTypes.KNOWS);
            rel.setProperty("disclosure", "public");
            Node smith = neo.createNode();
            smith.setProperty("name", "Agent Smith");
            smith.setProperty("version", "1.0b");
            smith.setProperty("language", "C++");
            rel = cypher.createRelationshipTo(smith, MyRelationshipTypes.KNOWS);
            rel.setProperty("disclosure", "secret");
            rel.setProperty("age", "6 months");
            Node architect = neo.createNode();
            architect.setProperty("name", "The Architect");
            smith.createRelationshipTo(architect, MyRelationshipTypes.CODED_BY);
            tx.success();
        }
        finally {
            tx.finish();
        }
    }

    @Test
    public void printNeoFriends() throws Exception {
        Transaction tx = Transaction.begin();
        try {
            printFriends(neoNode);
            tx.success();
        }
        finally {
            tx.finish();
        }
    }

    @Test
    public void printMatrixHackers() throws Exception {
        Transaction tx = Transaction.begin();
        try {
            findHackers(neoNode);
            tx.success();
        }
        finally {
            tx.finish();
        }
    }

    private static void printFriends(Node person) {
        System.out.println(person.getProperty("name") + "'s friends:");
        Traverser traverser = person.traverse(Order.BREADTH_FIRST,
                StopEvaluator.END_OF_NETWORK,
                ReturnableEvaluator.ALL_BUT_START_NODE, MyRelationshipTypes.KNOWS,
                Direction.OUTGOING);
        for (Node friend : traverser) {
            TraversalPosition position = traverser.currentPosition();
            System.out.println("At depth " + position.depth() + " => "
                    + friend.getProperty("name"));
        }
    }

    private static void findHackers(Node startNode) {
        System.out.println("Hackers:");
        Traverser traverser = startNode.traverse(Order.BREADTH_FIRST,
                StopEvaluator.END_OF_NETWORK, new ReturnableEvaluator() {
            public boolean isReturnableNode(
                    TraversalPosition currentPosition) {
                Relationship rel = currentPosition
                        .lastRelationshipTraversed();
                return rel != null && rel.isType(MyRelationshipTypes.CODED_BY);
            }
        }, MyRelationshipTypes.CODED_BY, Direction.OUTGOING,
                MyRelationshipTypes.KNOWS, Direction.OUTGOING);
        for (Node hacker : traverser) {
            TraversalPosition position = traverser.currentPosition();
            System.out.println("At depth " + position.depth() + " => "
                    + hacker.getProperty("name"));
        }
    }
}