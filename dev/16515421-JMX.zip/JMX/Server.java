package JMX;

import java.lang.management.ManagementFactory;
import java.rmi.registry.LocateRegistry;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;

public class Server {

    public static void main(String[] args) throws Exception {
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
        ObjectName name = new ObjectName("test:name=KillerMBean");
        KillerMBean mbean = new Killer();
        mbs.registerMBean(mbean, name);
        LocateRegistry.createRegistry(10990);
        JMXConnectorServerFactory.newJMXConnectorServer(
                new JMXServiceURL(
                        "service:jmx:rmi://localhost:10990/jndi/rmi://localhost:10990/service"),
                null, mbs).start();

        System.out.println("Waiting forever...");
        Thread.sleep(Long.MAX_VALUE);
    }

}
