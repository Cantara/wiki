package JMX;

public interface KillerMBean {

    void kill();
    
}
