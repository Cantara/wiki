package JMX;

public class Killer implements KillerMBean {

    @Override
    public void kill() {
        System.out.println("Killing myself in 3 sec");
        new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.exit(0);
            }
        }.start();
    }

}
