package JMX;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

public class Client {
    
    public static void main(String[] args) throws Exception {
        JMXConnector connector = JMXConnectorFactory.connect(new JMXServiceURL("service:jmx:rmi://localhost:10990/jndi/rmi://localhost:10990/service"));
        MBeanServerConnection connection = connector.getMBeanServerConnection();
        System.out.println("Killing");
        connection.invoke(new ObjectName("test:name=KillerMBean"), "kill", new Object[]{}, new String[]{});
        System.out.println("Closing");
        connector.close();
        System.out.println("Closed");
        while(true) {
            System.out.println("sleeping");
            Thread.sleep(1000);//Keep alive for possible exceptions
        }
    }
    
}
